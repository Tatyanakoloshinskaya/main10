from datetime import datetime
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from .forms import *
from .models import *
from django.views.generic import ListView

def index(request):
    return render(request, 'salon_app/base.html')

class ServicesListView(ListView):
    model = Service
    context_object_name = 'services'
    template_name = 'salon_app/services_list.html'

class MastersListView(ListView):
    model = Master
    context_object_name = 'masters'
    template_name = 'salon_app/masters.html'

@login_required
def Appointment(request):
    form = AppointmentForm()
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.client = request.user.client
            appointment.save()
            return redirect('profile')
    context = {'form': form}
    return render(request, 'salon_app/appointment.html', context)

def history_appointment(request):
    return render(request, 'salon_app/history.html')

@login_required
def cancelAppointmentPage(request, pk):
    appointment = get_object_or_404(Appointment, id=pk, client__user=request.user)
    if request.method == 'POST':
        appointment.status = False
        appointment.save()
        return redirect('profile')
    context = {'appointment': appointment}
    return render(request, 'salon_app/cancel_appointment.html', context)

def mastersCancelAppointmentPage(request, pk):
    appointment = get_object_or_404(Appointment, id=pk, master__user=request.user)
    if request.method == 'POST':
        appointment.status = False
        appointment.save()
        return redirect('masters_profile')
    context = {'appointment': appointment}
    return render(request, 'salon_app/masters_cancel_appointment.html', context)

def about(request):
    return render(request, 'salon_app/about.html')

def feedback(request):
    return render(request, 'salon_app/feedback.html')

def doLogout(request):
    logout(request)
    return render(request, 'salon_app/base.html')

def future_appointment(request):
    return render(request, 'salon_app/future_appointment.html')

def history_past_appointment(request):
    return render(request, 'salon_app/history_past_appointment.html')

def registerPage(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterForm()
    context = {'form': form}
    return render(request, 'salon_app/register.html', context)

def mastersregPage(request):
    if request.method == 'POST':
        form = MastersRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('masters_login')
    else:
        form = MastersRegisterForm()
    context = {'form': form}
    return render(request, 'salon_app/masters_register.html', context)

def loginPage(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('masters_profile')
    else:
        form = LoginForm()
    context = {'form': form}
    return render(request, 'salon_app/login.html', context)

def masterslogPage(request):
    if request.method == 'POST':
        form = MastersLoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('profile')
    else:
        form = MastersLoginForm()
    context = {'form': form}
    return render(request, 'salon_app/masters_login.html', context)


def profilePage(request):
    return render(request, 'salon_app/profile.html', {'client': request.client})


def mastersPage(request):
    if request.user.is_authenticated:
        master = Client.objects.get(pk = request.master.id)
    else:
        return  redirect('masters_login')
    return render(request, 'salon_app/masters_profile.html', {'master': request.master})




