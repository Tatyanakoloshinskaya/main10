from django.db import models
from django.db.models import *
from django.contrib.auth.models import User


class Service(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.IntegerField()

    def __str__(self):
        return self.name

class Feedback(models.Model):
    feedback_dt = models.DateTimeField(auto_now=True)
    feedback_name = models.CharField(max_length=100, verbose_name='Имя')
    feedback_phone = models.CharField(max_length=100, verbose_name='Номер телефона')

    def __str__(self):
        return f"{self.feedback_dt} - {self.feedback_name} - {self.feedback_phone}"

class Client(User):
    fio = models.CharField(max_length=128)
    phone = models.IntegerField()

class Master(User):
    fio = models.CharField(max_length=28)
    phone = models.IntegerField()
    experience = models.PositiveIntegerField()


class Appointment(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE, related_name='appointments')
    master = models.ForeignKey(Master, on_delete=models.CASCADE, related_name='appointments')
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()
    status = models.CharField(max_length=128)



