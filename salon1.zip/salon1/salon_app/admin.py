from django.contrib import admin
from .models import *

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'price')

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('fio', 'phone')

@admin.register(Master)
class MasterAdmin(admin.ModelAdmin):
    list_display = ('fio', 'phone', 'experience')

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('master', 'service','client', 'date', 'time')

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('feedback_dt', 'feedback_name', 'feedback_phone')
